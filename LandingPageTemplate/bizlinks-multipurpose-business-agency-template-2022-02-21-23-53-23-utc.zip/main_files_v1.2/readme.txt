BizLinks is a Material Design Multipurpose Business and Agency HTML Template designed for All kinds of Business and Creative Agency. It's an HTML template based on Material Design Lite and latest Bootstrap 3.3.7. Anyone can easily update/edit this template to follow our Well Sorted Documentation.


===============================================================
Well Sorted Documentation included in "documentation" (folder).
===============================================================


SOURCE AND CREADITS:
====================

Photos:

    - All 'images' used on the demo site is for demonstration purposes only and are not included in the main download file.
    - All Images Collected From 'Google Image Search'

Fonts Used:

    Google Fonts (Raleway) - http://www.google.com/webfonts
    Font Awesome - http://fontawesome.io/


Frameworks / Libraries:

    jQuery - https://jquery.com/
    Twitter Bootstrap - http://getbootstrap.com
    Material Design Lite - http://www.getmdl.io/


Plugins Used:

    Isotope - https://github.com/metafizzy/isotope
    jQuery Validation - http://jqueryvalidation.org/
    Waypoints - https://github.com/imakewebthings/waypoints/
    jQuery CounterUP - https://github.com/bfintal/Counter-Up
    Owl Carousel - https://github.com/OwlFonk/OwlCarousel
    Twitter Post Fetcher - https://github.com/jasonmayes/Twitter-Post-Fetcher
    Tubular - http://www.seanmccambridge.com/tubular/
    AnimateScroll - http://plugins.compzets.com/animatescroll/
    Scrollify - https://github.com/lukehaas/Scrollify
    Magnific Popup - http://dimsemenov.com/plugins/magnific-popup/
    RetinaJS - https://github.com/imulus/retinajs