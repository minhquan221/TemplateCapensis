var programmingSkills = [
    {
        value: 50,
        label: 'Total Projects - 50%',
        color: '#04c7d9'
    },
    {
        value: 50,
        label: 'Loan Programs - 50%',
        color: '#4175c8'
    }
];