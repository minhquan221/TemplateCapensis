const INSTAGRAM_DATA = [
  {
    image: '/assets/images/instagram/1.png',
    link: 'https://www.instagram.com/',
  },
  {
    image: '/assets/images/instagram/2.png',
    link: 'https://www.instagram.com/',
  },
  {
    image: '/assets/images/instagram/3.png',
    link: 'https://www.instagram.com/',
  },
  {
    image: '/assets/images/instagram/4.png',
    link: 'https://www.instagram.com/',
  },
  {
    image: '/assets/images/instagram/2.png',
    link: 'https://www.instagram.com/',
  },
  {
    image: '/assets/images/instagram/3.png',
    link: 'https://www.instagram.com/',
  },
];

export default INSTAGRAM_DATA;
