export enum ThemeVariation {
  Primary = 'primary',
  Secondary = 'secondary',
  Third = 'third',
  Fourth = 'fourth',
}
