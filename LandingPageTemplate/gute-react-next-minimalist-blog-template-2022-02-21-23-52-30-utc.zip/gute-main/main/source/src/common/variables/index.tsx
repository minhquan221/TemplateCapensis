export const SECTION_SPACING = 70;
