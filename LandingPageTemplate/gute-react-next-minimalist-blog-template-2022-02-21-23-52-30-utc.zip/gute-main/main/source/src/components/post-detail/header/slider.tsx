import React from 'react';

const slider = () => {
  return <div></div>;
};

export default slider;
