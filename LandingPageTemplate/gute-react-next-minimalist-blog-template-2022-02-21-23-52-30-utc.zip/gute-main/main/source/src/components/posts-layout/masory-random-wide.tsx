import { ThemeVariation } from '@common/enum';
import React from 'react';

const MasonryRandomWide = ({ theme }: { theme?: ThemeVariation }) => {
  return <></>;
};

export default MasonryRandomWide;
